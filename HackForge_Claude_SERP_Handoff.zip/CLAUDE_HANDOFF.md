# HackForge — Claude SERP Evidence Handoff

Prepared from the two uploaded SERP screenshot ZIP files.

## Evidence
All screenshots have been copied into `evidence/serp/` and renamed with:
- collection date
- evidence set
- keyword slug
- sequence number

See `evidence/serp/SERP_EVIDENCE_INDEX.csv` for the mapping.

## Important
The keyword names below are **inferred from the visible Google query text in the screenshots**. 
They should be checked against Claude's `serp_analysis.md` before finalizing the six required rows.

### Set A
1. hackathon problem statements
2. AI hackathon
3. online hackathon
4. student hackathon
5. hackathon registeration (spelling shown in screenshot)
6. coding hackathon

### Set B
1. problem statement for hackathon
2. hackathon problem statements with solutions
3. how to participate in hackathon
4. hackathon challenges
5. AI ideas for hackathon
6. AI project ideas for hackathon

## What the screenshots visibly support
The evidence includes Google SERP screenshots, PAA/People also search for sections on several queries, ranking order, result titles/snippets, and page-inspection/word-counter screenshots for some ranking pages.

## Do not infer unsupported fields
Content length and heading structure should only be marked complete where the screenshots actually capture the relevant page content/HTML or a full word count. 
A word-counter screenshot containing only a page title is **title length, not full page content length**.

Featured snippet:
- Record `Not observed` where no traditional featured-snippet box is visible.
- Do not classify Google's AI Overview as a featured snippet.

## Remaining project metadata
The following still require user/project confirmation and have intentionally not been invented:
- Niche confirmation
- Prototype notice wording
- Host/VPS naming/provider
- Student name
- Roll number
- Submission deadline

## File rename requested by Claude
Claude requested:
`research/keyword_collection_quide.md` -> `research/keyword_collection_guide.md`

That source file was not included in the two uploaded SERP ZIPs, so it could not be renamed here without the original project/repository files.
