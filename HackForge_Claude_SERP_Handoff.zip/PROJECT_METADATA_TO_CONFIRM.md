# Claude Open Items — Fill Before Handoff

Niche confirmation:
[ENTER CONFIRMED NICHE]

Prototype notice:
[ENTER/APPROVE WORDING]

Host/VPS naming:
[ENTER HOST/VPS PROVIDER OR CONFIRM UNDECIDED]

Student name:
[ENTER NAME]

Roll number:
[ENTER ROLL NUMBER]

Milestone I deadline:
[ENTER VERIFIED DEADLINE]
